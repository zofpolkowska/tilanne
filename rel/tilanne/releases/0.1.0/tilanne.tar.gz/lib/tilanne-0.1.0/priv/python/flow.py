from __future__ import print_function
import tensorflow as tf
from erlport.erlang import cast
from erlport.erlterms import Atom

def test():
    text = tf.constant('TensorFlow TEST')
    return "TensorFlowTest"



